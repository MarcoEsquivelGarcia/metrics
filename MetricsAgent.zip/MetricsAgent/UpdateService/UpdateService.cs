﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using MetricAgentResource;
using System.IO;
using System.Reflection;

namespace UpdateService
{
    public class UpdateService
    {
        private FileHandler _fileHandler;
        private ProcessHandler _processHandler;

        public UpdateService(FileHandler fileHandler, ProcessHandler processHandler)
        {
            _fileHandler = fileHandler;
            _processHandler = processHandler;
        }

        public static void Main()
        {

        }
        public  void StartUpdate()
        {
            //Call kill process for update yml files
            _processHandler.KillProcess();
            //Update yml files 
            _fileHandler.GetYmlFiles();

        }


    }
}
