﻿using MetricAgentResource;
using MetricAgentResource.Properties;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstallService
{
    public class Installer
    {

        private readonly ILogger<Installer> _logger;
        private readonly FileHandler _fileHandler;
        private readonly ZipFileHandler _zipHandler;
        private readonly InstallHandler _installHandler;




        public Installer(ILogger<Installer> logger, FileHandler fileHandler, ZipFileHandler zipFileHandler, InstallHandler installHandler)
        {
            _logger = logger;
            _fileHandler = fileHandler;
            _zipHandler = zipFileHandler;
            _installHandler = installHandler;
        }

        public static void Main()
        {
           
        }
        public void StartInstaller()
        {
            //Starting the installation
            _logger.LogInformation("Initializating IproMetricsCollections installer");
            _logger.LogInformation( "Checking directory");
            //Checking if the root folder exist to download all the files
            _fileHandler.CheckDirectoryIfExist(@Resources.rootFolderPath);
            _logger.LogInformation( "Starting downloading Files");
            //Downloading the resources
            _installHandler.DownloadResources();

            //Unziping the files
            _logger.LogInformation( "Unziping files");
            _logger.LogInformation( " >> Unziping Sql Exporter");
            _zipHandler.UnzipFResources(@Resources.sqlExporterLocalPath, @Resources.sqlCompressedFileName);
            _logger.LogInformation( ">> Unzipping Prometheus");
            _zipHandler.UnzipFResources(@Resources.prometheusLocalPath, @Resources.prometheusCompressedFileName);
            _logger.LogInformation( ">> Unziping Grafana");
            _zipHandler.UnzipFResources(@Resources.grafanaLocalPath, @Resources.grafanaCompressedFileName);
        }
    }
}
