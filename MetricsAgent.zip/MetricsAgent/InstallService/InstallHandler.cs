﻿using MetricAgentResource;
using MetricAgentResource.Properties;
using Microsoft.Extensions.Logging;
using System;
using System.Net;

namespace InstallService
{
    public class InstallHandler
    {

        private ILogger<InstallHandler> _logger;
        private FileHandler _fileHandler;

        public InstallHandler(ILogger<InstallHandler> logger, FileHandler fileHandler)
        {
            _logger = logger;
            _fileHandler = fileHandler;
        }

        //Calls the DownloadFile method 
        public void DownloadResources()
        {
           _logger.LogInformation(" >> Downloading Sql_Exporter please wait...");
            DownloadFile(@Resources.sqlExporterGitUrl, Resources.sqlExporterLocalPath);
           _logger.LogInformation(" >> Downloading Prometheus please wait... ");
            DownloadFile(@Resources.prometheusGitUrl, @Resources.prometheusLocalPath);
           _logger.LogInformation(" >> Downloading Grafana please wait...");
            DownloadFile(@Resources.grafanaGitUrl, @Resources.grafanaLocalPath);
        }


        //Donwload the resources that we need for the installation
        public void DownloadFile(string url, string filePath)
        {
            string filename = getFileName(url);
            using (WebClient downloader = new WebClient())
            {
                //Cheking the directory
                _fileHandler.CheckDirectoryIfExist(filePath);
                //Download the files
                downloader.DownloadFile(new Uri(url), filePath + "/" + filename);
               _logger.LogInformation(">>Download Completed!!! \n");
            }

        }

        //Get the file name of the compressed file
        public static string getFileName(string hreflink)
        {
            Uri uri = new Uri(hreflink);

            string filename = System.IO.Path.GetFileName(uri.LocalPath);

            return filename;
        }
    }
}
