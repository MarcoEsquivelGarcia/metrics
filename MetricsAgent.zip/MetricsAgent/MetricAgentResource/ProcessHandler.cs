﻿using MetricAgentResource.Properties;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetricAgentResource
{
    public class ProcessHandler
    {
        private ILogger<ProcessHandler> _logger;
        public ProcessHandler(ILogger<ProcessHandler> logger)
        {
            _logger = logger;
        }

        //Passing a path to file exe and executing this file, 
        public  void RunProcess(string workingDirectory, string fileName)
        {


            try
            {
                Directory.SetCurrentDirectory(workingDirectory);
                using (Process process = new Process())
                {
                    process.StartInfo.UseShellExecute = false;
                    process.StartInfo.FileName = fileName;
                    process.StartInfo.CreateNoWindow = true;
                    process.StartInfo.Verb = "runas";
                    process.Start();

                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
            }

        }

        //Kill all proces that can make the installation fail.
        public  void KillProcess()
        {

            _logger.LogInformation( "Killing Services... please wait");
            //Collection of all process name involve
            string[] processName = { Path.GetFileNameWithoutExtension(Resources.grafanaServerExecFileName),
                                     Path.GetFileNameWithoutExtension(Resources.prometheusExecFileName),
                                     Path.GetFileNameWithoutExtension(Resources.sqlExporterExecFileName) };
            //Killing each of one of the process list
            foreach (Process process in processName.SelectMany(Process.GetProcessesByName))
            {
                _logger.LogInformation( " >> Killing "+ process.ProcessName +"services... please wait");
                process.Kill();
            }


        }
    }
}
