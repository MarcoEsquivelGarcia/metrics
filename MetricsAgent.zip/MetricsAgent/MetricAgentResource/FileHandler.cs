﻿using MetricAgentResource.Properties;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Resources;
using System;
using System.Collections;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using MetricAgentResource.YAMLHelpers;

namespace MetricAgentResource
{
    public  class FileHandler
    {


        private ILogger<FileHandler> _logger;

        public FileHandler(ILogger<FileHandler> logger)
        {
            _logger = logger;
        }

        //Check if the directory exist if not, it crates one
        public  void CheckDirectoryIfExist(string path)
        {
            if (!Directory.Exists(path))
            {
                System.IO.Directory.CreateDirectory(path);
            }

        }
        //Overload of the CheckDirectoryIfExsit with a path and a filename, if exist de directory, it create a file inside
        public  void CheckDirectoryIfExist(string path, string filename)
        {
            if (!Directory.Exists(path))
            {
                System.IO.Directory.CreateDirectory(filename);
            }

        }

        //Check if a file exist
        public  void CheckExeFileExist(string path)
        {
            if (!File.Exists(path))
            {
                // Create a file to write to.

            }
        }
        public void CreateYmlFile()
        {
            //Get current directory
            var path = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory).Parent.Parent.Parent.FullName;
            path = Path.Combine(path.Replace("LauncherService", "MetricAgentResource"), @Resources.YMLTemplateDirectory);
            var connStr = "sqlserver://srvqadev:T3sting@int_alpha_sql01.testing.local:1433?database=int_alpha_ADD";
            //Create new YML file based on template
            var file = new FileInfo(path + Resources.YMLTemplateName);

            YMLHandler.CreateFile(file, connStr, Resources.YMLTemplateName);
           
        }
        public  void GetYmlFiles()
        {
           

            //First Create de sql_Exporter yml file
            CreateYmlFile();

            //Get all files of each directory of YML and replace/copy each of one into the corresponding directory
            string[] ymlFolder = { Resources.YMLSqlExporterDirectory, Resources.YMLPrometheusExporterDirectory};
            foreach (var folder in ymlFolder)
            {
                string RunningPath = AppDomain.CurrentDomain.BaseDirectory;
                string ymlFilesDirectory = string.Format("{0}Resources\\" + folder, Path.GetFullPath(Path.Combine(RunningPath.Replace("LauncherService", "MetricAgentResource"), @"..\..\..\")));
                Directory.CreateDirectory(@Resources.sqlExporterExecLocalPath);

                if (folder.StartsWith("sql_exporter"))
                    _logger.LogInformation("Updating Sql Exporter YML Files");
                else
                    _logger.LogInformation("Updating Prometheus YML Files");


                var exelocalpath = folder.StartsWith("sql_exporter") ? @Resources.sqlExporterExecLocalPath : Resources.prometheusExecLocalPath;
                //Deleting mssql_standar file that come as default
                if (Path.GetFileName(@Resources.YMLCollectorDefault).Contains("mssql_standard"))
                    DeleteFile(Path.Combine(exelocalpath, Path.GetFileName(@Resources.YMLCollectorDefault)));


                foreach (var file in Directory.GetFiles(ymlFilesDirectory))
                {
                    if (!File.Exists(Path.Combine(exelocalpath, Path.GetFileName(file))))
                    {
                        File.Copy(file, Path.Combine(exelocalpath, Path.GetFileName(file)));

                    }
                    else
                    {
                        DeleteFile(Path.Combine(exelocalpath, Path.GetFileName(file)));
                        File.Copy(file, Path.Combine(exelocalpath, Path.GetFileName(file)));
                        
                    }
                   
                }
         }

        }

        //Delete a File passing a path

        public  void DeleteFile(string pathToFile)
        {
            File.Delete(pathToFile);
        }

        //Delete a Directory passing a path to the directory
        public  void DeleteDirectory(string pathToDirectory)
        {
            Directory.Delete(pathToDirectory);
        }
    }
}
