﻿using MetricAgentResource.Properties;
using MetricAgentResource.YAMLHelpers;
using Microsoft.Extensions.Logging;
using System;
using System.IO;

namespace MetricAgentResource
{
    class MetricAgentResource
    {
        public static void Main()
        {
          
           
        }
    }
}
