﻿using MetricAgentResource.Properties;
using System.IO;
using YamlDotNet.Core;
using YamlDotNet.RepresentationModel;

namespace MetricAgentResource.YAMLHelpers
{
    public class YMLHandler
    {
        /// <summary>
        /// Create a new YML file based on defined template
        /// </summary>
        /// <param name="template"></param>
        /// <param name="connectionString"></param>
        /// <param name="newFileName"></param>
        public static void CreateFile(FileInfo template, string connectionString, string newFileName)
        {
            using (var reader = new StreamReader(template.FullName))
            {
                // Load the stream
                var yaml = new YamlStream();
                yaml.Load(reader);

                // Examine the stream
                var mapping =
                    (YamlMappingNode)yaml.Documents[0].RootNode;

                //Set datasource value
                mapping.Children[Resources.YMLTargetNode] = new YamlMappingNode
                {
                    { Resources.YMLTargetDataSource, new YamlScalarNode(connectionString) { Style = ScalarStyle.DoubleQuoted } },
                    { Resources.YMLCollectors, new YamlScalarNode(Resources.YMLCollectorsValue) { Style = ScalarStyle.DoubleQuoted } }
                   
                };

                //Get directory to push new file 
                var path = new DirectoryInfo(template.DirectoryName).Parent.FullName;
                path = Path.Combine(path, @Resources.YMLSqlExporterDirectory, newFileName);

                //Create new YML file
                using (var stWriter = new StreamWriter(path))
                {
                    yaml.Save(stWriter, false);
                }

                //Delete double quoted
                string text = File.ReadAllText(path);
                text = text.Replace("\"" + Resources.YMLCollectorsValue + "\"", Resources.YMLCollectorsValue);
                File.WriteAllText(path, text);
            }
        }
    }
}
