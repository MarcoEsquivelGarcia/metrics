﻿using MetricAgentResource.Properties;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace MetricAgentResource
{
    public class RemoveInstallation
    {
        private ProcessHandler _processHandler;
        private FileHandler _fileHandler;

        public RemoveInstallation(ProcessHandler processHandler, FileHandler fileHandler)
        {
            _processHandler = processHandler;
            _fileHandler = fileHandler;
        }
        public  void Main()
        {
            //Kill process if still running
            _processHandler.KillProcess();
            //Deleting all files
            _fileHandler.DeleteDirectory(@Resources.rootFolderPath);
        }
    }
}
