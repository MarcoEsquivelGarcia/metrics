﻿using ICSharpCode.SharpZipLib.GZip;
using ICSharpCode.SharpZipLib.Tar;
using Ionic.Zip;
using System.IO;

namespace MetricAgentResource
{
    public  class ZipFileHandler
    {
        private readonly FileHandler _fileHandler;
        public ZipFileHandler(FileHandler fileHandler)
        {
            _fileHandler = fileHandler;
        }


        //Unzip a file format .zip or tar.gz
        public  void UnzipFResources(string filePath, string fileName)
        {
            string zipFilePath = filePath + "/" + fileName;
            string extractedFilePath = filePath;

            if (fileName.EndsWith(".zip"))
            {
                using (Ionic.Zip.ZipFile zipfile = Ionic.Zip.ZipFile.Read(zipFilePath))
                {
                    //Check directory if exist for extrac files of compressed zip file
                    _fileHandler.CheckDirectoryIfExist(extractedFilePath, zipFilePath);

                    //Unziping fe compressed file, copy all file to the new directory
                    foreach (ZipEntry e in zipfile)
                    {
                        e.Extract(extractedFilePath, ExtractExistingFileAction.OverwriteSilently);
                    }

                }
                //Deleting the compressed file
                _fileHandler.DeleteFile(zipFilePath);

            }
            else
            {

                FileInfo tarFileInfo = new FileInfo(zipFilePath);
                //Check directory if exist for extrac files of compressed zip file
                DirectoryInfo targetDirectory = new DirectoryInfo(filePath);

                //Unziping fe compressed file, copy all file to the new directory
                using (Stream sourceStream = new GZipInputStream(tarFileInfo.OpenRead()))
                {
                    using (TarArchive tarArchive = TarArchive.CreateInputTarArchive(sourceStream, TarBuffer.DefaultBlockFactor))
                    {
                        tarArchive.ExtractContents(targetDirectory.FullName);
                    }
                }
                //Deleting the compressed file
                _fileHandler.DeleteFile(zipFilePath);

            }
        }
    }
}
