﻿using MetricAgentResource;
using MetricAgentResource.Properties;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LauncherService
{
    class RestartHandler
    {

        public static void RestartProcess()
        {

            //ProcessHandler.KillProcess();

           // StartHandler.StartServices();
        }
    }
}
