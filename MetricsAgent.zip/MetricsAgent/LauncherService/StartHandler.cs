﻿using MetricAgentResource.Properties;
using MetricAgentResource;
using System;
using InstallService;
using System.Diagnostics;
using System.IO;
using UpdateService;
using Microsoft.Extensions.Logging;

namespace LauncherService
{
    public  class StartHandler
    {

        private ILogger<StartHandler> _logger;
        private ProcessHandler _processHandler;
        private Installer _installer;
        private UpdateService.UpdateService _updateService;



        public StartHandler(ILogger<StartHandler> logger, ProcessHandler processHandler, Installer installer, UpdateService.UpdateService updateService)
        {
            _logger = logger;
            _processHandler = processHandler;
            _installer = installer;
            _updateService = updateService;
        }

        //Call to to update the yml files
        public  void StartUpdateYmlFiles()
        {
            _updateService.StartUpdate();
        }

        //Call the initialization of the installer
        public  void StartInstaller()
        {
            _installer.StartInstaller();

        }
        public  void StartServices()
        {
            //Starting the services
            _logger.LogInformation("Starting Services");
            _logger.LogInformation(" >> Starting Sql Exporter Services");
            _processHandler.RunProcess(Resources.sqlExporterExecLocalPath, Resources.sqlExporterExecFileName);
            _logger.LogInformation(" >> Starting prometheus Services");
            _processHandler.RunProcess(Resources.prometheusExecLocalPath, Resources.prometheusExecFileName);
            _logger.LogInformation(" >> Starting Grafana Services");
            _processHandler.RunProcess(Resources.grafanaExecLocalPath, Resources.grafanaServerExecFileName);
        }

    }
}
