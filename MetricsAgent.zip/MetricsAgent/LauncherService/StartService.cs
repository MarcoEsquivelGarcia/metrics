﻿using InstallService;
using MetricAgentResource;
using MetricAgentResource.Properties;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog;
using NLog.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LauncherService
{
    class StartServices
    {
        public static void Main()
        {

            //Starting the dependency injection for the logger
            var logger = LogManager.GetCurrentClassLogger();
            try
            {
                var config = new ConfigurationBuilder()
                   .SetBasePath(System.IO.Directory.GetCurrentDirectory()) //From NuGet Package Microsoft.Extensions.Configuration.Json
                   .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                   .Build();

                var servicesProvider = ConfigureServices(config).BuildServiceProvider();
                var startup = servicesProvider.GetRequiredService<Startup>();

                startup.Run();



            }
            catch (Exception ex)
            {
                // NLog: catch any exception and log it.
                logger.Error(ex, "Stopped program because of exception");
                throw;
            }
            finally
            {
                // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
                LogManager.Shutdown();
            }

           

        }

        //Services created for the dependency injection for the logger
        public static IServiceCollection ConfigureServices(IConfiguration config)
        {
            return new ServiceCollection()
               .AddTransient<Startup>() // Runner is the custom class
               .AddTransient<ProcessHandler>()
               .AddTransient<StartHandler>()
               .AddTransient<Installer>()
               .AddTransient<FileHandler>()
               .AddTransient<InstallHandler>()
               .AddTransient<ZipFileHandler>()
               .AddTransient<UpdateService.UpdateService>()
               .AddTransient<RemoveInstallation>()
               

               .AddLogging(loggingBuilder =>
               {
                       // configure Logging with NLog
                       loggingBuilder.ClearProviders();
                   loggingBuilder.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Trace);
                   loggingBuilder.AddNLog(config);
               });

        }
    }

    public class Startup
    {
        private ProcessHandler _processHandler;
        private StartHandler _startHandler;

        public Startup(ProcessHandler processHandler, StartHandler startHandler)
        {
            _processHandler = processHandler;
            _startHandler = startHandler;
        }

        public void Run()
        {
            //Kill process if they are still running
            _processHandler.KillProcess();
            //Start installer
            _startHandler.StartInstaller();
            //Create and update the yml files
            _startHandler.StartUpdateYmlFiles();
            //Start the services
            _startHandler.StartServices();
        }
    }
}
